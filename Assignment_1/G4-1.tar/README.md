# Embedded

## The shared repository to work on Concurrent Programming Labs.

Contributors: Dimitris Voitsidis, Iordana Gaisidou and Stavros Stathoudakis.

## File Structure

![Project diagram](filestructure.svg)